﻿using System;

namespace VehicleMaintenanceForm
{
    public class Vehicle
    {
        public string Model { get; private set; }
        public int Year { get; private set; }
        public int Kilometers { get; private set; }

        public Vehicle(string model, int year, int kilometers)
        {
            if (model.Length > 15)
                throw new ArgumentException("Model name cannot exceed 15 characters.");

            if (year < 1990 || year > 2025)
                throw new ArgumentOutOfRangeException("Year must be between 1990 and 2025.");

            if (kilometers < 0 || kilometers > 250000)
                throw new ArgumentOutOfRangeException("Kilometers must be between 0 and 250000.");

            Model = model;
            Year = year;
            Kilometers = kilometers;
        }

        public string GetModel() => Model;
        public int GetYear() => Year;
        public int GetKilometers() => Kilometers;
    }
}
