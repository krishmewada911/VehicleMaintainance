using NUnit.Framework;
using VehicleMaintenanceForm;
using System;

namespace VehicleMaintenanceTest
{
    [TestFixture]
    public class VehicleTests
    {
        [Test]
        public void GetModel_ValidModel_ReturnsModel()
        {
            var vehicle = new Vehicle("ToyotaCamry", 2020, 50000);
            Assert.AreEqual("ToyotaCamry", vehicle.GetModel());
        }

        [Test]
        public void GetYear_ValidYear_ReturnsYear()
        {
            var vehicle = new Vehicle("HondaCivic", 2025, 120000);
            Assert.AreEqual(2025, vehicle.GetYear());
        }

        [Test]
        public void GetKilometers_ValidKilometers_ReturnsKilometers()
        {
            var vehicle = new Vehicle("FordFocus", 2015, 200000);
            Assert.AreEqual(200000, vehicle.GetKilometers());
        }

        [Test]
        public void Vehicle_InvalidModel_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() => new Vehicle("ThisModelIsWayTooLong123", 2020, 50000));
        }

        [Test]
        public void Vehicle_InvalidYear_ThrowsException()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new Vehicle("TeslaModelX", 1985, 50000));
        }

        [Test]
        public void Vehicle_InvalidKilometers_ThrowsException()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new Vehicle("NissanAltima", 2021, 300000));
        }
    }
}
